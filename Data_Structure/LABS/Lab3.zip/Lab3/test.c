#include <stdio.h>

int main()
{
    int count[10] = {0};
    int i;
    for (i = 0; i < 10; i++)
    {
        printf("%d\n", count[i]);
    }
}